import { describe, expect, test } from "bun:test";
import type { HistorySession } from "./gym-types";
import {
  completedSetForReopenedWorkout,
  getCurrentWeekDates,
  getCurrentWeekWorkoutSession,
  getWorkoutCompletion,
  normalizeWeekday,
  restForWorkoutSet,
} from "./workout-session";

const session = (date: string): HistorySession => ({
  id: "session-1",
  workoutId: "workout-1",
  workoutName: "אימון",
  date,
  durationSec: 600,
  entries: [
    {
      exerciseId: "exercise-1",
      exerciseName: "תרגיל",
      notes: "",
      sets: [
        { reps: 10, weight: 20, done: true },
        { reps: 8, weight: 20, done: true },
      ],
    },
  ],
});

describe("reopening a completed workout", () => {
  test("restores this week's completed session and its working-set marks", () => {
    const completed = getCurrentWeekWorkoutSession(
      [session("2026-08-30T08:00:00.000Z")],
      "workout-1",
      new Date("2026-08-31T12:00:00.000Z"),
    );

    expect(completed?.id).toBe("session-1");
    expect(completedSetForReopenedWorkout(completed?.entries[0], 0)).toBe(true);
    expect(completedSetForReopenedWorkout(completed?.entries[0], 1)).toBe(true);
    expect(completedSetForReopenedWorkout(completed?.entries[0], 2)).toBe(false);
  });

  test("does not carry completion marks into a new week", () => {
    const completed = getCurrentWeekWorkoutSession(
      [session("2026-08-29T08:00:00.000Z")],
      "workout-1",
      new Date("2026-08-31T12:00:00.000Z"),
    );

    expect(completed).toBeUndefined();
  });

  test("does not mark unfinished working sets when reopening a partial session", () => {
    const partialEntry = {
      ...session("2026-08-31T12:00:00.000Z").entries[0]!,
      sets: [
        { reps: 10, weight: 20, done: true },
        { reps: 8, weight: 20, done: false },
      ],
    };

    expect(completedSetForReopenedWorkout(partialEntry, 0)).toBe(true);
    expect(completedSetForReopenedWorkout(partialEntry, 1)).toBe(false);
  });
});

describe("weekly scheduling", () => {
  test("maps Sunday-first weekday slots to the current calendar week", () => {
    const week = getCurrentWeekDates(new Date(2026, 7, 30, 12));

    expect(week.map((day) => day.weekday)).toEqual([0, 1, 2, 3, 4, 5, 6]);
    expect(week.map((day) => day.date)).toEqual([
      "2026-08-30",
      "2026-08-31",
      "2026-09-01",
      "2026-09-02",
      "2026-09-03",
      "2026-09-04",
      "2026-09-05",
    ]);
    expect(week[0]?.isToday).toBe(true);
  });

  test("rejects weekday values outside the Sunday-first range", () => {
    expect(normalizeWeekday("0")).toBe(0);
    expect(normalizeWeekday("6")).toBe(6);
    expect(normalizeWeekday("7")).toBeUndefined();
    expect(normalizeWeekday("not-a-day")).toBeUndefined();
  });
});

describe("weekly workout completion", () => {
  test("distinguishes a partial session from a fully completed plan", () => {
    const partial = getWorkoutCompletion(session("2026-08-31T12:00:00.000Z"), 3);
    expect(partial.doneSets).toBe(2);
    expect(partial.targetSets).toBe(3);
    expect(partial.percent).toBe(67);
    expect(partial.status).toBe("partial");

    const complete = getWorkoutCompletion(
      {
        ...session("2026-08-31T12:00:00.000Z"),
        entries: [
          {
            ...session("2026-08-31T12:00:00.000Z").entries[0]!,
            sets: [
              ...session("2026-08-31T12:00:00.000Z").entries[0]!.sets,
              { reps: 8, weight: 20, done: true },
            ],
          },
        ],
      },
      3,
    );
    expect(complete.percent).toBe(100);
    expect(complete.status).toBe("completed");
  });
});

describe("per-set rest", () => {
  test("prefers the configured working-set rest over the exercise default", () => {
    expect(
      restForWorkoutSet(
        {
          id: "item-1",
          exerciseId: "exercise-1",
          sets: 2,
          reps: 10,
          weight: 20,
          rest: 90,
          notes: "",
          workingSets: [
            { id: "set-1", setNumber: 1, weight: 20, reps: 10, rest: 45 },
            { id: "set-2", setNumber: 2, weight: 20, reps: 10, rest: 75 },
          ],
        },
        1,
      ),
    ).toBe(75);
  });

  test("falls back safely for legacy items without per-set rest", () => {
    expect(
      restForWorkoutSet(
        {
          id: "item-1",
          exerciseId: "exercise-1",
          sets: 1,
          reps: 10,
          weight: 20,
          rest: 90,
          notes: "",
        },
        0,
      ),
    ).toBe(90);
    expect(restForWorkoutSet(undefined, 0)).toBe(60);
  });
});

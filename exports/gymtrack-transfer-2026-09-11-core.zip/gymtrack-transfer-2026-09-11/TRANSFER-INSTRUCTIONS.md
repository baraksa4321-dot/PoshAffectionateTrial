# GymTrack project transfer

This archive contains the GymTrack source code, tests, public assets, Supabase migrations, and native Android/iOS project source needed to recreate the app in another Replit project.

## Intentionally excluded

- `node_modules` and generated dependency folders
- Web/native build outputs (`.output`, `dist`, `dist-mobile`, native `build` folders)
- Test reports and caches
- `.git` history
- Secret values and local `.env` files

These exclusions do not remove application source and keep credentials out of the archive.

## Setup in the new project

1. Extract the archive and use `gymtrack-working` as the application directory.
2. Install dependencies from its lockfile: `npm ci`.
3. Copy the required Replit Secrets into the new project through the Secrets UI. Never paste secret values into source files.
4. Connect the new project to the existing Supabase/Firebase services if you want to retain the same live users, database rows, uploaded exercise images, and Push configuration.
5. If using a new Supabase project instead, apply every SQL migration in `gymtrack-working/supabase/migrations` in order and migrate database/Storage data separately.
6. Run `npm run typecheck`, the project tests, and the production build before publishing.

## Important data boundary

The ZIP contains code and migration definitions, but it cannot contain live Supabase database rows, Supabase Storage objects, Firebase configuration held as secrets, authentication accounts, or Replit project secrets. Keeping the same backend connections preserves that live data. Moving to new backend projects requires a separate database and Storage export/import.

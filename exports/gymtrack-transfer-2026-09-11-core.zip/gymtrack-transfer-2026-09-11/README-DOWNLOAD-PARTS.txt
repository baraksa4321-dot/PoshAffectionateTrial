Download all three ZIP files and extract them into the same destination folder:
1. gymtrack-transfer-2026-09-11-core.zip
2. gymtrack-transfer-2026-09-11-loading-flat.zip
3. gymtrack-transfer-2026-09-11-loading-extra.zip

Allow folders to merge. The two loading archives add files under gymtrack-working/public/loading. Android/iOS generated web bundles are intentionally omitted; they are recreated from the web source during the Capacitor build/sync process.
